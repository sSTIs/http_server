//
//  server_socket.h
//
//
//  Created by sSTIs on 05.03.16.
//
//

#include <iostream>
#include <cstring>

#include <netdb.h>
//#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <sys/types.h>
#include <netinet/in.h>

using namespace std;

class SocketAddress
{
    struct sockaddr_in address;
public:
    SocketAddress(const char *hostname, short port);
    struct sockaddr_in *getAddress();
};

// Socket classes
//!--------------------------------------------------------------------------------------

// base class
class Socket
{
protected:
    int _sd;
public:
    Socket();
    ~Socket();
};

// with input output
class IOSocket : public Socket
{
public:
    IOSocket();
    IOSocket(int sd);
    int send(void *buffer, size_t n);
    int receive(void *buffer, size_t n);
};

// IO + connect for client
class ConnectionSocket : public IOSocket
{
public:
    void connect(SocketAddress *pAddress);
};

//server
class ServerSocket: public Socket
{
public:
    void bind(SocketAddress *pAddress);
    void listen();
    void accept();
protected:
    virtual void on_accept(IOSocket *pSocket) = 0;
};

class MyServerSocket: public ServerSocket
{
public:
    virtual void on_accept(IOSocket *pSocket);
};
