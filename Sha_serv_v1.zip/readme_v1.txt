make all or make server + make browser
./server ./browser
server_socket.h - header of server_socket.cpp - Socket classes
Version 1
Browser sends const request (GET /), server sends (501 Not Implemented)