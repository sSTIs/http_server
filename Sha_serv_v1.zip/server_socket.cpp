//
//  server_socket.cpp
//
//
//  Created by sSTIs on 05.03.16.
//
//

#include "server_socket.h"

using namespace std;

// class SocketAddress
//!======================================================================================
SocketAddress::SocketAddress(const char *hostname, short port)
{
    struct hostent *hostent_struct;
    hostent_struct = ::gethostbyname(hostname);
    
    address.sin_family = AF_INET;
    address.sin_port = htons(port);
    memcpy(&address.sin_addr, hostent_struct->h_addr, hostent_struct->h_length);
}

struct sockaddr_in *SocketAddress::getAddress()
{
    return &address;
}

//class Socket
//!======================================================================================
Socket::Socket()
{
    if ((_sd = ::socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("Socket didn't created");
        exit(1);
    }
}

Socket::~Socket()
{
    if (_sd >= 0)
    {
        ::shutdown(_sd, SHUT_RDWR);
        close(_sd);
    }
}

// class IOSocket
//!======================================================================================
IOSocket::IOSocket()
{
    //? for new connection socket
}

IOSocket::IOSocket(int sd)
{
    close(_sd); // for accept socket, that already exist
    _sd = sd;
}

int IOSocket::send(void *buffer, size_t n)
{
    int len;
    len = ::send(_sd, buffer, n, 0);
    if (len != n)
    {
        cerr << "Send failed" << endl;
    }
    return len;
}

int IOSocket::receive(void *buffer, size_t n)
{
    int len;
    len = ::recv(_sd, buffer, n, 0);
    if (len == -1)
    {
        cerr << "Receive failed" << endl;
    }
    return len;
}

// class ConnectionSocket
//!======================================================================================
void ConnectionSocket::connect(SocketAddress *pAddress)
{
    if (::connect(_sd, (struct sockaddr*) pAddress -> getAddress(), sizeof(struct sockaddr_in)) < 0)
    {
        perror("Connection failed");
        exit(2);
    }
}

// class ServerSocket
//!======================================================================================
void ServerSocket::bind(SocketAddress *pAddress)
{
    if (::bind(_sd, (struct sockaddr*) pAddress -> getAddress(), sizeof(struct sockaddr_in)) < 0)
    {
        perror("Bind failed");
        exit(3);
    }
}

void ServerSocket::listen()
{
    const int backlog = 5; //number of requests
    if (::listen(_sd, backlog) < 0)
    {
        perror("Listen failed");
        exit(4);
    }
}

void ServerSocket::accept()
{
    int new_socket_sd;
    if ((new_socket_sd = ::accept(_sd, NULL, NULL)) < 0)
    {
        perror("Accept failed");
        exit(5);
    }
    IOSocket *new_socket = new IOSocket(new_socket_sd);
    on_accept(new_socket);
}

// Final classes
// class ServerSocket
//!======================================================================================
void MyServerSocket::on_accept(IOSocket *pSocket)
{
    char buffer[10240];
    int n = pSocket -> receive(buffer, sizeof(buffer)-1);
    buffer[n]=0;
    //analizis of request
    char *response = (char *)"501 Not Implemented HTTP/1.1\r\n\r\n";
    pSocket -> send(response, strlen(response)-1);
    delete pSocket;

}
